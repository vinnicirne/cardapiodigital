<?php
define('HOME', 'https://olhardigital.xyz/delivery256/clientedemo/');
setlocale( LC_ALL, 'pt_BR', 'pt_BR.iso-8859-1', 'pt_BR.utf-8', 'portuguese' );