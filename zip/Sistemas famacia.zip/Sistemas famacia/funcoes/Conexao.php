<?php
$servidor = 'localhost';
$usuario  = 'id22252864_cardapiodigital';
$senha 	  = 'Vinicius@1105';
$banco    = 'id22252864_cardapiodigital';

// FUNCOES DO SISTEMA DE CADASTRO ###########

$nomesite  = 'Cardapio Digital';
$urlmaster = 'https://dashboard-cardapiodigital.000webhostapp.com'; // APENAS A URL PRINCIPAL SEM A BARRA NO FINAL ---- ----

date_default_timezone_set('America/Sao_Paulo');

